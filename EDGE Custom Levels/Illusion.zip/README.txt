How do I install the level?

1. Open Steam
2. Right click EDGE
3. Click Properties > Local Files > Browse
4. Go back and open the "models" folder then drag the "C91CD5B5050DB82A.eso" file in this folder to there
5. Go back and open the "levels" folder and drag the "illusion.bin" file in this folder to there
6. Edit mapping.xml in the "levels" folder.
7. Search </standard>, </extended> or </bonus> and paste the following string behind the text you searched:

<level filename="illusion" name_sfx="illusion"/>

10. Save the file

Enjoy the level!
