How do I install level?

1. Download the files
2. Open Steam
3. Right click EDGE
4. Click Properties > Local Files > Browse
5. Open the "models" folder and drag "DA2C1C7D050DB82A.eso" from the repository to there
7. Go back and open the "levels" folder and drag "portal" from the repository to there
8. Edit mapping.xml in the "levels" folder.
9. Search </standard>, </extended> or </bonus> and paste the following string behind the text you searched:

<level filename="portal" leaderboard_id="70558" name_sfx="portal"/>

10. Save the file
Enjoy the level!
