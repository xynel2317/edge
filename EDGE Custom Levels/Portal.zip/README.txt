How do I install level?

1. Download the files
2. Open Steam
3. Right click EDGE
4. Click Properties > Local Files > Browse
5. Open the "models" folder and drag "DA2C1C7D050DB82A.eso" from this folder to there
7. Go back and open the "levels" folder and drag "portal" from this folder to there
8. Edit mapping.xml in the "levels" folder.
9. Search </standard>, </extended> or </bonus> and paste the following string behind the text you searched:

<level filename="portal" leaderboard_id="70558" name_sfx="portal"/>

10. Save the file
11. (Optional) Install EDGETool 9.2.0 (https://github.com/Mygod/EDGE/releases/tag/9.2.0) and open the "(De)compile" tab and drag the "audio" folder to there. You will get a new folder named "sfx". Drag "levelsfx_portal" from this folder to there, then put the "sfx" folder in the "(De)compile" tab

Enjoy the level!
